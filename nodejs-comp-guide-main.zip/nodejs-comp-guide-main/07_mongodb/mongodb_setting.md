# Mongodb Setting - 接続方法 -

- Atlasタブを選択されているか確認
- サイドバーの Deployment > Databaseが選択されているか確認
- クラスター名横のConnectボタンクリック
 
## IPアドレス接続
Add Your Current IP addressクリック(自分のIPがわかっていれば入力してもよい)

## ユーザーの作成
1. 入力
    - Username: codemafia
    - password: rjV3ZB2bK3A5WWuC(Autogenerate Secure Passwordクリック)
2. Create Database Userクリック
3. Choose a connection methodクリック

## 接続方法の選択
サンプルを示してくれるだけなので、実際はどれを選んでも大丈夫。
- Connect your applicationを選択
- プログラミング言語ごとの、接続方法が表示される。
- Node.jsを参考にすすめる


