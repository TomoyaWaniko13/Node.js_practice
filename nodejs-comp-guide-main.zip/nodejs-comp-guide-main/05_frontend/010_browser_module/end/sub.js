function helloFromSub() {
    console.log('hello, sub');
}

export {
    helloFromSub
}

// module.exports = {
//     helloFromSub
// }