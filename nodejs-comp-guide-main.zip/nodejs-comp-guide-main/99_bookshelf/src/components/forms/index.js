export { default as InputBookTitle } from "./InputBookTitle";
export { default as InputBookDesc } from "./InputBookDesc";
export { default as InputBookComment } from "./InputBookComment";
export { default as InputBookRating } from "./InputBookRating";
