import isOdd from "is-odd";

const result = isOdd(3);

console.log(result);