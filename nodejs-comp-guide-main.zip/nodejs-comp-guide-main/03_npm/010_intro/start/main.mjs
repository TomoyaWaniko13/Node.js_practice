const original = { prop: { nested: "value" } };
// オブジェクトの複製
