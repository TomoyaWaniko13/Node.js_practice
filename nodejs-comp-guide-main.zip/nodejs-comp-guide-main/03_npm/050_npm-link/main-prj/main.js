import hello from 'lib-prj';

console.log(hello())