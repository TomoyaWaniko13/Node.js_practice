export default function hello() {
    return 'hell';
}