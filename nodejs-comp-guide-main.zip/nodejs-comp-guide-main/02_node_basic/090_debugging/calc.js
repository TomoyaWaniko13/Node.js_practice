function plus(a, b) {
  const result = a + b;
  return result;
}
function minus(a, b) {
  return a - b;
}

module.exports = {
  plus,
  minus,
};
