function plus(a, b) {
  return a + b;
}
const result = plus(1, 2);
console.log(result);
