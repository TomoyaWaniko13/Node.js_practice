const { plus } = require('./calc');
const result = plus(1, 2);
console.log(result);
