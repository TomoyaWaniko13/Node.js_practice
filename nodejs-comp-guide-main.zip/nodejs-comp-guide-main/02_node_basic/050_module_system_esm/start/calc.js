function plus(a, b) {
  return a + b;
}
function minus(a, b) {
  return a - b;
}

module.exports = {
  plus,
  minus,
};
