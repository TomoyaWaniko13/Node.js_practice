export function plus(a, b) {
  return a + b;
}
export default function minus(a, b) {
  return a - b;
}

// export {
//   plus,
//   minus,
// };
