﻿# expo アプリの動かし方
1. 下記のコマンドを実行

```sh
npm install
```

2. 開発サーバーを起動

```sh
npm start
```